// 現在は動作確認用のサンプルです。
// 本番版では、ここを現役男役253人の正式な候補者データに差し替えます。
// 写真は権利関係を確認したうえで、利用可能な画像を設定してください。
const CANDIDATES = [
  {id:"sample01",name:"永久輝 せあ",troupe:"花組",image:""},
  {id:"sample02",name:"風間 柚乃",troupe:"月組",image:""},
  {id:"sample03",name:"朝美 絢",troupe:"雪組",image:""},
  {id:"sample04",name:"天飛 華音",troupe:"星組",image:""},
  {id:"sample05",name:"朱 涼",troupe:"宙組",image:""},
  {id:"sample06",name:"奈央 麗斗",troupe:"宙組",image:""},
  {id:"sample07",name:"海咲 圭",troupe:"雪組",image:""},
  {id:"sample08",name:"夕渚 りょう",troupe:"星組",image:""},
  {id:"sample09",name:"希沙 薫",troupe:"星組",image:""},
  {id:"sample10",name:"輝月 ゆうま",troupe:"専科",image:""},
  {id:"sample11",name:"蒼真 唯斗",troupe:"組回り",image:""},
  {id:"sample12",name:"煌世 涼",troupe:"組回り",image:""}
];
