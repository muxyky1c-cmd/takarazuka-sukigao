const $=s=>document.querySelector(s);
const screens={start:$("#start"),game:$("#game"),result:$("#result")};
let pool=[],round=0,selected=[],survivors=[],finalists=[];

function shuffle(a){return [...a].sort(()=>Math.random()-.5)}
function show(name){Object.values(screens).forEach(x=>x.classList.remove("active"));screens[name].classList.add("active")}
function makeCard(p){
  const b=document.createElement("button"); b.className="card";
  b.innerHTML=`<div class="portrait" ${p.image?`style="background-image:url('${p.image}');background-size:cover;background-position:center"`:""}></div><div class="check">✓</div><div class="card-info"><div class="name">${p.name}</div><div class="troupe">${p.troupe}</div></div>`;
  b.onclick=()=>{if(b.classList.contains("selected")){b.classList.remove("selected");selected=selected.filter(x=>x.id!==p.id)}else if(selected.length<2){b.classList.add("selected");selected.push(p)} updateNext()};
  return b;
}
function updateNext(){
  $("#nextBtn").disabled=selected.length!==2;
  $("#nextBtn").textContent=selected.length===2?"この2人を選択":"2人選ぶと次へ";
}
function renderRound(){
  selected=[];updateNext();$("#cards").innerHTML="";
  const cards=shuffle(pool).slice(0,4);
  cards.forEach(p=>$("#cards").appendChild(makeCard(p)));
  $("#countLabel").textContent=`${pool.length}人中`;
  $("#progress").textContent=round===0?"予選":"決勝ラウンド";
}
function next(){
  survivors.push(...selected);
  pool=pool.filter(p=>!selected.some(s=>s.id===p.id));
  // デモ版は2回で結果へ。本番版では253→127/128→64→18→9の進行に置き換えます。
  if(survivors.length>=6 || pool.length<4){finalists=shuffle(survivors).slice(0,9);renderResult()}
  else {round++;renderRound()}
}
function renderResult(){
  const list=$("#resultList");list.innerHTML="";
  shuffle(finalists).slice(0,9).forEach((p,i)=>{
    const row=document.createElement("div");row.className="result-row";
    row.innerHTML=`<div class="rank">${i+1}</div><div><div class="rname">${p.name}</div><div class="rtroupe">${p.troupe}</div></div>`;
    list.appendChild(row);
  });show("result");
}
$("#startBtn").onclick=()=>{pool=shuffle(CANDIDATES);survivors=[];round=0;show("game");renderRound()};
$("#nextBtn").onclick=next;
$("#againBtn").onclick=()=>{$("#startBtn").click()};
